#'Sample Vertex Attributes for NARMS_EC_DATA
#'
#'A small data frame that contains vertex metadata for variables in the NARMS_EC_DATA set.  See also documentation for "Assign_Vmetadata"
#'
#'@name V_ATTRS
#'
#'@docType data
#'
#'@usage data(V_ATTRS)
#'
#'@format A dataframe from with 61 rows and 5 columns
#' \describe{
#'	\item{Code}{A 3 letter code identifying the drug resistance}
#'	\item{Drug}{Full name of the drug}
#'	\item{Class}{A 5 character code identifying the class of drug resistance (e.g., B-LAC for beta-lactam resistance)}
#'	\item{color}{Assigned vertex color for resistance}
#'	\item{label.color}{Assigned vertex label color for resistance}
#'
#' }
NULL