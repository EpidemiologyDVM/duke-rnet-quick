## ---- echo = FALSE, results = 'hide', message = F------------------------
library(Rnets)

#Define the set of antimicrobials to include in the Rnet
ABX_LIST <- c('AMC', 'AXO', 'TIO', 'CIP', 'TET', 'STR', 'GEN', 'CHL')

## ------------------------------------------------------------------------
EC_all_L1Selection <- L1Selection(
            x = NARMS_EC_DATA, 
            L1_values = seq(0.05, 0.45, 0.05),
            n_b = 1500,
            vert = ABX_LIST,
            verbose = F
            )

summary(EC_all_L1Selection)

## ------------------------------------------------------------------------
#Estimate the Rnet
EC_all_Rnet <- Rnets::Rnet(x = NARMS_EC_DATA, L1 =  0.15, vert = ABX_LIST)
                
#View Results
summary(EC_all_Rnet)

## ------------------------------------------------------------------------
EC_2008_Rnet <- Rnets::Rnet(x = NARMS_EC_DATA, L1 =  0.15, vert = ABX_LIST, subset = expression (Year == 2008))

summary(EC_2008_Rnet)

## ------------------------------------------------------------------------
EC_byYear_Rnet <- Rnets::Rnet(x = NARMS_EC_DATA, L1 =  0.15, vert = ABX_LIST, subset = 'Year')

summary(EC_byYear_Rnet)

## ------------------------------------------------------------------------
Rnets::V_ATTRS[1:10,]

## ------------------------------------------------------------------------
Assign_Vmetadata(EC_2008_Rnet, V_ATTRS, match_attr = 'Code', V_match_attr = 'name')


## ------------------------------------------------------------------------
Rnets::E_ATTRS

## ------------------------------------------------------------------------


